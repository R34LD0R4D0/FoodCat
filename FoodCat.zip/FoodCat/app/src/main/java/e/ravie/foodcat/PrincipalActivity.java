package e.ravie.foodcat;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import e.ravie.foodcat.Adapter.RecetaAdapter;
import e.ravie.foodcat.Adapter.Recetas;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class PrincipalActivity extends AppCompatActivity {

    Button btnLogOut, btnSugerencia;
    RecyclerView recyclerRecetas;
    ArrayList<Recetas> ListaRecetas;
    private TextView txt_correo;

    String RECETAS_URL = "https://proyectosisp/zay/FoodCat/obtenerEquipos.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);
        btnLogOut=findViewById(R.id.btnLogOut);


        //----------------------------------------------------------------
        txt_correo=(TextView)findViewById(R.id.txt_correo);
        String dato= getIntent().getStringExtra("dato");
        txt_correo.setText(dato);
        //................................................................


        btnLogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences preferences=getSharedPreferences("preferenciasLogin", Context.MODE_PRIVATE);
                preferences.edit().clear().commit();

                Intent intent= new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra("dato", txt_correo.getText().toString());
                startActivity(intent);
                finish();
            }
        });
        btnSugerencia=findViewById(R.id.btnSugerencia);

        btnSugerencia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent=new Intent(getApplicationContext(), SugerenciaReceta.class);
                startActivity(intent);
            }
        });
        recyclerRecetas= findViewById(R.id.recicler);
        recyclerRecetas.setLayoutManager(new GridLayoutManager(this,2));

        ListaRecetas= new ArrayList<Recetas>();
        obtenerRecetas();
    }

    public void obtenerRecetas(){
        RequestQueue requestQueue= Volley.newRequestQueue(getApplicationContext());

        StringRequest stringRequest= new StringRequest(Request.Method.POST, RECETAS_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("Recetas");

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject1 = jsonArray.getJSONObject(i);

                                String auxFoto = jsonObject1.getString("img_foto");
                                String auxNombre = jsonObject1.getString("txt_correo_receta");

                                auxFoto = auxFoto.replace("", "%20");
                                auxFoto = auxFoto.replace("localhost", "https://proyectosisp.com");

                                ListaRecetas.add(new Recetas(auxNombre, auxNombre));
                            }

                            RecetaAdapter adapter = new RecetaAdapter(ListaRecetas);

                            recyclerRecetas.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    }, new Response.ErrorListener(){
                            @Override
                            public void onErrorResponse(VolleyError error){
                                error.printStackTrace();
                        }
                });
        requestQueue.add(stringRequest);
    }
}