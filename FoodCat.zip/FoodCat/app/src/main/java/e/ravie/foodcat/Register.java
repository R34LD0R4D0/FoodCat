package e.ravie.foodcat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.Map;

public class Register extends AppCompatActivity {

    EditText edtNewCorreo, edtNewPass, edtNewName, edtNewLastName;
    Button btnNewRegistro;
    ImageView imagenGatito2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        imagenGatito2= findViewById(R.id.imagenGatito2);
        Picasso.get()
                .load("http://proyectosisp.com/zay/FoodCat/img/LoginJahn5.png")
                .error(R.mipmap.ic_launcher_round)
                .into(imagenGatito2);

        edtNewCorreo=findViewById(R.id.edtNewCorreo);
        edtNewPass=findViewById(R.id.edtNewPass);
        edtNewName=findViewById(R.id.edtNewName);
        edtNewLastName=findViewById(R.id.edtNewLastName);
        btnNewRegistro=findViewById(R.id.btnNewRegistro);

        btnNewRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                agregarUsuario("https://proyectosisp.com/zay/FoodCat/insertar_usuario.php");
            }
        });
    }

    public void regresarInicio(View view){
        Intent intent= new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void agregarUsuario(String URL){
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                    Toast.makeText(getApplicationContext(),"OPERACION EXITOSA", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                Toast.makeText(Register.this, error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parametros=new HashMap<String, String>();
                parametros.put("correo_usuario",edtNewCorreo.getText().toString());
                parametros.put("pass_usuario",edtNewPass.getText().toString());
                parametros.put("nombre_usuario",edtNewName.getText().toString());
                parametros.put("apellidos_usuario",edtNewLastName.getText().toString());

                return parametros;
            }
        };

        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }
}