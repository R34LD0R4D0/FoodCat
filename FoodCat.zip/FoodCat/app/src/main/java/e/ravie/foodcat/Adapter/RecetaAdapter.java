package e.ravie.foodcat.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import e.ravie.foodcat.R;

public class RecetaAdapter extends RecyclerView.Adapter<RecetaAdapter.ViewHolderRecetas>{
    ArrayList<Recetas> ListaRecetas;

    public RecetaAdapter(ArrayList<Recetas> ListaRecetas){
        this.ListaRecetas= ListaRecetas;
    }
    @NotNull
    @Override
    public RecetaAdapter.ViewHolderRecetas onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.activity_principal, null, false);

        return new ViewHolderRecetas(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderRecetas viewHolderRecetas, int position) {
        Picasso.get().load(ListaRecetas.get(position).getImg_foto()).resize(400, 500).into(viewHolderRecetas.img_foto);
        viewHolderRecetas.txt_nombre_receta.setText(ListaRecetas.get(position).getTxt_nombre_receta());

    }

    @Override
    public int getItemCount() {
        return ListaRecetas.size();
    }

    public class ViewHolderRecetas extends RecyclerView.ViewHolder {

        ImageView img_foto;
        TextView txt_nombre_receta;

        public ViewHolderRecetas(@NotNull View itemView) {
            super(itemView);
            img_foto= itemView.findViewById(R.id.img_foto);
            txt_nombre_receta= itemView.findViewById(R.id.txt_nombre_receta);
        }
    }
}
