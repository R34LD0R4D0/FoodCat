package e.ravie.foodcat.Adapter;

public class Recetas {
    private String img_foto;
    private String txt_nombre_receta;

    public Recetas(String txt_nombre_receta, String img_foto) {
        this.img_foto=img_foto;
        this.txt_nombre_receta=txt_nombre_receta;
    }

    public String getImg_foto() {
        return img_foto;
    }

    public void setImg_foto(String img_foto) {
        this.img_foto = img_foto;
    }

    public String getTxt_nombre_receta() {
        return txt_nombre_receta;
    }

    public void setTxt_nombre_receta(String txt_nombre_receta) {
        this.txt_nombre_receta = txt_nombre_receta;
    }

    @Override
    public String toString() {
        return "Recetas{" +
                "img_foto='" + img_foto + '\'' +
                ", txt_nombre_receta='" + txt_nombre_receta + '\'' +
                '}';
    }
}
