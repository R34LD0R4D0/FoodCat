package e.ravie.foodcat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    EditText edtUsuario, edtPass;
    Button btnLogin, btnRegister;
    String usuario, pass;
    ImageView imagenGatito;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtUsuario= findViewById(R.id.edtUsuario);
        edtPass= findViewById(R.id.edtPassword);
        btnLogin= findViewById(R.id.btnLogin);
        btnRegister= findViewById(R.id.btnRegister);


        imagenGatito= findViewById(R.id.imagenGatito);
        Picasso.get()
                .load("http://proyectosisp.com/zay/FoodCat/img/LoginJahn4.png")
                .error(R.mipmap.ic_launcher_round)
                .into(imagenGatito);

        recuperarPreferencias();

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                usuario=edtUsuario.getText().toString();
                pass=edtPass.getText().toString();
                if(!usuario.isEmpty() && !pass.isEmpty()){
                    validarUsuario("https://proyectosisp.com/zay/FoodCat/login.php");
                }else{
                    Toast.makeText(MainActivity.this, "No se permiten campos vacios", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void nuevoRegistro(View view){
        Intent intent2= new Intent(getApplicationContext(), Register.class);
         startActivity(intent2);
    }

    private void validarUsuario(String URL){
        StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if(!response.isEmpty()){
                    guardarPreferencias();
                    Intent intent=new Intent(getApplicationContext(), PrincipalActivity.class);
                    intent.putExtra("dato", usuario.toString());
                    startActivity(intent);
                    finish();
                }else{
                    Toast.makeText(MainActivity.this,"usuario o contraseña incorrecta", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                Toast.makeText(MainActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parametros=new HashMap<String, String>();
                parametros.put("correo_usuario", usuario);
                parametros.put("pass_usuario", pass);
                return parametros;
            }
        };

        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }


    private void guardarPreferencias(){
        SharedPreferences preferences= getSharedPreferences("preferenciasLogin", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor=preferences.edit();
        editor.putString("usuario", usuario);
        editor.putString("password", pass);
        editor.putBoolean("sesion", true);
        editor.commit();
    }

    private void recuperarPreferencias(){
        SharedPreferences preferences= getSharedPreferences("preferenciasLogin", Context.MODE_PRIVATE);
        edtUsuario.setText(preferences.getString("usuario", "@gmail.com"));
        edtPass.setText(preferences.getString("password", ""));
    }
}